#include "JavaFace.h"
#include <stdlib.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdarg.h>
#include <dlfcn.h>
#include <string.h>

extern "C" {
void *filehandle = NULL;

void (*init)( char *, char * ) = NULL;
int (*getDat)(char * , char * ) = NULL;



char* Jstring2CStr( JNIEnv * env, jstring jstr )
{ 
 char*   rtn   =   NULL; 
 jclass   clsstring   =   (*env).FindClass("java/lang/String");  
 jstring   strencode   =  (*env).NewStringUTF("GB2312"); 
 jmethodID   mid   =   (*env).GetMethodID(clsstring,   "getBytes",   "(Ljava/lang/String;)[B");  
 jbyteArray   barr=   (jbyteArray)(*env).CallObjectMethod(jstr,mid,strencode); 
 jsize   alen   =  (*env).GetArrayLength(barr); 
 jbyte*   ba   =   (*env).GetByteArrayElements(barr,JNI_FALSE); 
 if(alen   >   0) 
 { 
  rtn   =   (char*)malloc(alen+1);         //new   char[alen+1]; 
  memcpy(rtn,ba,alen); 
  rtn[alen]=0; 
 } 
 (*env).ReleaseByteArrayElements(barr,ba,0); 
 
 return rtn;
}  




JNIEXPORT void JNICALL Java_JavaFace_init (JNIEnv * env, jclass obj,jstring src, jstring dst)
{
    filehandle = dlopen("libface.so", RTLD_LAZY);
    if(filehandle)
    {

	char *src1 = (char*)(*env).GetStringUTFChars(src, 0);
	char *dst1 = (char*)(*env).GetStringUTFChars(dst, 0);
 
      //printf("-->%s<--\n",src1);

     init = (void (*)(char * , char *))dlsym(filehandle,"init");
	
     //printf("-->%s<--\n",dst1);

     if(init)
        init(src1,dst1);


     dlclose(filehandle);
     filehandle = NULL;
    }
}

JNIEXPORT jint JNICALL Java_JavaFace_GetDat (JNIEnv * env, jclass obj,jstring src, jstring dst)
{
    filehandle = dlopen("libface.so", RTLD_LAZY);
    if(filehandle)
    {

	char *src1 = (char*)(*env).GetStringUTFChars(src, 0);
	char *dst1 = (char*)(*env).GetStringUTFChars(dst, 0);
 
    
	 getDat = (int (*)(char * , char *))dlsym(filehandle,"GetDat");

     int var = -2;
	 if(getDat)
       var = getDat(src1,dst1);


     dlclose(filehandle);
     filehandle = NULL;
	 return var;
    }
}


}
