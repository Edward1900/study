//package com.example.demo.util;

public class JavaFace {

	public native void init(String path1, String path2);

	public native int GetDat(String src_path, String dst_path);

	static
	{

		System.load("/home/feng/work/javaFace/javaFace.so");
	}
	public static void main(String[] args){
		String a = "/home/feng/work/javaFace/1.jpg";
		String b = "/home/feng/work/javaFace/2.dat";
		JavaFace javaFace = new JavaFace();
		javaFace.init("/home/feng/work/javaFace/001.dat","/home/feng/work/javaFace/002.dat");
		int res = javaFace.GetDat(a,b);
		System.out.println(res);
	}


	
}
