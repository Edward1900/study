// The contents of this file are in the public domain. See LICENSE_FOR_EXAMPLE_PROGRAMS.txt

//#include "face.h"
#include <dlib/dnn.h>
#include <dlib/gui_widgets.h>
#include <dlib/clustering.h>
#include <dlib/string.h>
#include <dlib/image_io.h>
#include <dlib/image_processing/frontal_face_detector.h>
#include <iostream>
#include <fstream>
#include <sstream>

using namespace dlib;
using namespace std;

//void init(char* src_path, char*  dst_path);
//int GetDat(char* src_path, char*  dst_path);



// ----------------------------------------------------------------------------------------

template <template <int, template<typename>class, int, typename> class block, int N, template<typename>class BN, typename SUBNET>
using residual = add_prev1<block<N, BN, 1, tag1<SUBNET>>>;

template <template <int, template<typename>class, int, typename> class block, int N, template<typename>class BN, typename SUBNET>
using residual_down = add_prev2<avg_pool<2, 2, 2, 2, skip1<tag2<block<N, BN, 2, tag1<SUBNET>>>>>>;

template <int N, template <typename> class BN, int stride, typename SUBNET>
using block = BN<con<N, 3, 3, 1, 1, relu<BN<con<N, 3, 3, stride, stride, SUBNET>>>>>;

template <int N, typename SUBNET> using ares = relu<residual<block, N, affine, SUBNET>>;
template <int N, typename SUBNET> using ares_down = relu<residual_down<block, N, affine, SUBNET>>;

template <typename SUBNET> using alevel0 = ares_down<256, SUBNET>;
template <typename SUBNET> using alevel1 = ares<256, ares<256, ares_down<256, SUBNET>>>;
template <typename SUBNET> using alevel2 = ares<128, ares<128, ares_down<128, SUBNET>>>;
template <typename SUBNET> using alevel3 = ares<64, ares<64, ares<64, ares_down<64, SUBNET>>>>;
template <typename SUBNET> using alevel4 = ares<32, ares<32, ares<32, SUBNET>>>;

using anet_type = loss_metric<fc_no_bias<128, avg_pool_everything<
	alevel0<
	alevel1<
	alevel2<
	alevel3<
	alevel4<
	max_pool<3, 3, 2, 2, relu<affine<con<32, 7, 7, 2, 2,
	input_rgb_image_sized<150>
	>>>>>>>>>>>>;

// ----------------------------------------------------------------------------------------

// ----------------------------------------------------------------------------------------
frontal_face_detector detector = get_frontal_face_detector();
shape_predictor sp;
anet_type net;


extern "C"  void init(char* src_path, char*  dst_path)
{
	std::string path1, path2;
	path1.assign(src_path);
	path2.assign(dst_path);

	deserialize(path1) >> sp;
	// And finally we load the DNN responsible for face recognition.
	deserialize(path2) >> net;

}


std::vector<matrix<float, 0, 1>> comput_vector(matrix<rgb_pixel> img, std::vector<rectangle> face)
{
	std::vector<matrix<rgb_pixel>> faces;

	auto shape = sp(img, face[0]);
	matrix<rgb_pixel> face_chip;
	extract_image_chip(img, get_face_chip_details(shape, 150, 0.25), face_chip);
	faces.push_back(move(face_chip));


	if (faces.size() == 0)
	{
		cout << "No faces found in image!" << endl;
		
	}

	std::vector<matrix<float, 0, 1>> face_descriptors = net(faces);

	return face_descriptors;

}

int SaveDat(std::string path1, std::string path2) //path1Ϊimg·����path2Ϊdat·��
{
	//serialize("metric_network_renset.dat") << net;
	matrix<rgb_pixel> img;
	std::vector<matrix<float, 0, 1>> src_vector;
	//cv::Mat img = cv::imread("bald_guys.jpg",0);
	load_image(img, path1);

	std::vector<rectangle> face = detector(img);
	if (face.size() > 0)
	{
		src_vector = comput_vector(img, face);
		serialize(path2) << src_vector[0];
		return 1;
	}
	else {
		cout << "no face." << endl;
		return 0;

	}


}


int no_face_num = 0;
std::vector<matrix<float, 0, 1>> get_src_vector(std::string path)
{
	matrix<rgb_pixel> img;
	std::vector<matrix<float, 0, 1>> src_vector;
	//cv::Mat img = cv::imread("bald_guys.jpg",0);
	load_image(img, path);
	//resize_image(0.5, img);
	
	std::vector<rectangle> face = detector(img);
	if (face.size() > 0)
	{
		src_vector = comput_vector(img, face);
	}
	else { 
		no_face_num++;cout << "no face." << endl;
		
	}

	return src_vector;
}

int align(matrix<rgb_pixel> img, matrix<rgb_pixel>& aface)
{
	std::vector<rectangle> face = detector(img);
	auto shape = sp(img, face[0]);
	matrix<rgb_pixel> face_chip;
	extract_image_chip(img, get_face_chip_details(shape, 150, 0.25), face_chip);

	aface = move(face_chip);
	if (face.size() > 0)
	{
		return 1;
	}
	else {
		return 0;
	}
}

std::vector<matrix<float, 0, 1>> get_src_vectors(std::string path, std::string path2)
{
	matrix<rgb_pixel> img,aimg;
	matrix<rgb_pixel> img2,aimg2;
	std::vector<matrix<float, 0, 1>> src_vector;
	//cv::Mat img = cv::imread("bald_guys.jpg",0);
	load_image(img, path);
	load_image(img2, path2);
	
	
	std::vector<matrix<rgb_pixel>> faces;

	int f1 = align(img, aimg);int f2 = align(img2, aimg2);
	faces.push_back(aimg);faces.push_back(aimg2);
	
	if ((f1==1)&&(f2==1))
	{
		src_vector = net(faces);
	}
	else {
		cout << "no face." << endl;

	}

	return src_vector;
}


int compare(std::string path, matrix<rgb_pixel> img, std::vector<rectangle> face)
{
	int flag = 0;
	
	std::vector<matrix<float, 0, 1>> src_vector = get_src_vector(path);
	

	
	std::vector<matrix<float, 0, 1>> face_vector = comput_vector(img, face);
	
	if ((src_vector.size() > 0) && (face_vector.size() > 0))
	{
		if (length(src_vector[0] - face_vector[0]) < 0.5)
		{
			flag = 1;
		}
	}
	else { flag = -1; }

	return flag;
}

int CompareDat(std::string path1, std::string path2)//path1-img ;path2-dat
{
	int flag = 0;

	std::vector<matrix<float, 0, 1>> src_vector1 = get_src_vector(path1);
	std::vector<matrix<float, 0, 1>> src_vector2;// = get_src_vector(path2);
	matrix<float, 0, 1> dat1;
	deserialize(path2) >> dat1;
	src_vector2.push_back(dat1);

	if ((src_vector1.size() > 0) && (src_vector2.size() > 0))
	{
		if (length(src_vector1[0] - src_vector2[0]) < 0.5)
		{
			flag = 1;
		}
	}
	else { flag = -1; }

	return flag;
}

int CompareImg(std::string path1, std::string path2)
{
	int flag = 0;

	std::vector<matrix<float, 0, 1>> src_vector1 = get_src_vector(path1);
	std::vector<matrix<float, 0, 1>> src_vector2 = get_src_vector(path2);
	
	
	if ((src_vector1.size() > 0) && (src_vector2.size() > 0))
	{
		if (length(src_vector1[0] - src_vector2[0]) < 0.5)
		{
			flag = 1;
		}
	}
	else { flag = -1; }

	return flag;
}


extern "C"  int GetDat(char* src_path, char*  dst_path)
{
	std::string path1, path2;
	path1.assign(src_path);
	path2.assign(dst_path);

	int f = SaveDat(path1, path2);

	return f;
}

extern "C"  int FaceID(char* img_path, char*  dat_path)
{
	std::string path1, path2;
	path1.assign(img_path);
	path2.assign(dat_path);
	int f = CompareDat(path1, path2);

	return f;
}




